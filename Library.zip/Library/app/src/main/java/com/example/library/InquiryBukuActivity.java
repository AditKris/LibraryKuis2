package com.example.library;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.library.Adapter.LibraryAdapter;
import com.example.library.Adapter.LibraryAdapter;
import com.example.library.Model.Buku;

import java.util.ArrayList;

import io.realm.Realm;
import io.realm.RealmResults;

public class InquiryBukuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inquiry_buku);
        Realm realm = Realm.getDefaultInstance();
        RealmResults<Buku> buku =
                realm.where(Buku.class).findAll();
        ArrayList<Buku> arrayofuser = new ArrayList<>();
        arrayofuser.addAll(realm.copyFromRealm(buku));
        realm.close();

        LibraryAdapter libraryAdapter = new LibraryAdapter(this,arrayofuser);
        ListView listView = (ListView) findViewById(R.id.listviewbuku);
        listView.setAdapter(libraryAdapter);
    }
}