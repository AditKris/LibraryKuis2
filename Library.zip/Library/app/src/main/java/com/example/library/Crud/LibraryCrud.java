package com.example.library.Crud;

import android.util.Log;

import com.example.library.Model.Buku;

import io.realm.Realm;
import io.realm.exceptions.RealmPrimaryKeyConstraintException;

public class LibraryCrud {
    public void tambahDataBuku(String id, String judul, String pengarang, String penerbit, String tahun){
        Realm realm = Realm.getDefaultInstance();
        //penyimpanan data
        realm.executeTransaction(new Realm.Transaction() {
             @Override
             public void execute(Realm realm) {
                 try {
                     Buku buku = realm.createObject(Buku.class,id);
                     buku.setTitle(judul);
                     buku.setAuthor(pengarang);
                     buku.setPublisher(penerbit);
                     buku.setYear(tahun);
                 }
                 catch (RealmPrimaryKeyConstraintException e){
                     Log.d("Tag","Primary Key Sudah Ada + " + e.getMessage().toString());
                 }

             }
         }
    );
        realm.close();
    }
    public void updateDataBuku(String id, String judul, String pengarang, String penerbit, String tahun){
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
             @Override
             public void execute(Realm realm) {
                 try {
                     Buku buku = realm.where(Buku.class).equalTo("id",id).findFirst();
                     buku.setTitle(judul);
                     buku.setAuthor(pengarang);
                     buku.setPublisher(penerbit);
                     buku.setYear(tahun);
                 }
                 catch (RealmPrimaryKeyConstraintException e){
                     Log.d("Tag","Primary Key Sudah Ada + " + e.getMessage().toString());
                 }
             }
         }
    );
        realm.close();
    }
    public void deleteDataBuku(String id){
        Realm realm = Realm.getDefaultInstance();
        //penyimpanan data
        realm.executeTransaction(new Realm.Transaction() {
             @Override
             public void execute(Realm realm) {
                 try {
                     Buku buku = realm.where(Buku.class).equalTo("id",id).findFirst();
                     buku.deleteFromRealm();
                 }
                 catch (RealmPrimaryKeyConstraintException e){
                     Log.d("Tag","Primary Key Sudah Ada + " + e.getMessage().toString());
                 }

             }
         }
    );
        realm.close();
    }
}

