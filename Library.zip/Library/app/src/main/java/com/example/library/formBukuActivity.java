package com.example.library;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.library.R;

import org.w3c.dom.Text;

import io.realm.Realm;
import io.realm.exceptions.RealmPrimaryKeyConstraintException;
import com.example.library.Model.Buku;

public class formBukuActivity extends AppCompatActivity {

    EditText edtId, edtJudul, edtPengarang, edtPenerbit, edtTahun;
    Button btnSimpan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_buku);

        edtId = findViewById(R.id.edtId);
        edtJudul = findViewById(R.id.edtJudul);
        edtPenerbit = findViewById(R.id.edtPenerbit);
        edtPengarang = findViewById(R.id.edtPengarang);
        edtTahun = findViewById(R.id.edtTahun);
        btnSimpan = findViewById(R.id.btnSimpanBuku);

        btnSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = edtId.getText().toString();
                String judul = edtJudul.getText().toString();
                String pengarang = edtPengarang.getText().toString();
                String penerbit = edtPenerbit.getText().toString();
                String tahun = edtTahun.getText().toString();
                tambahDataBuku(id, judul, pengarang, penerbit, tahun);
            }
        });
    }

    public void tambahDataBuku(String id, String judul, String pengarang, String penerbit, String tahun){
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                try {
                    Buku buku = realm.createObject(Buku.class, id);
                    buku.setTitle(judul);
                    buku.setAuthor(pengarang);
                    buku.setPublisher(penerbit);
                    buku.setYear(tahun);
                    finish();
                } catch (RealmPrimaryKeyConstraintException e) {
                    Log.d("TAG", "Primary Key Sudah Ada + " + e.getMessage());
                }
            }
        });
        realm.close();
    }
}
