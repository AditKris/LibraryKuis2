package com.example.library.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.library.Crud.LibraryCrud;
import com.example.library.EditBukuActivity;
import com.example.library.Model.Buku;
import com.example.library.R;

import java.util.List;

public class LibraryAdapter extends ArrayAdapter<Buku> {
    public LibraryAdapter(Context context, List<Buku> objects) {
        super(context, 0, objects);
    }

    @Override
    public View getView(int position,  View convertView,  ViewGroup parent) {
        Buku buku =getItem(position);
        if (convertView==null){
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.layout_listview,parent,false);
        }

        TextView idTextView = convertView.findViewById(R.id.id);
        TextView bukuTextView = convertView.findViewById(R.id.buku);
        TextView pengarangTextView = convertView.findViewById(R.id.pengarang);
        TextView penerbitTextView = convertView.findViewById(R.id.penerbit);
        TextView tahunTextView = convertView.findViewById(R.id.tahun);

        idTextView.setText(buku.getId());
        bukuTextView.setText(buku.getTitle());
        pengarangTextView.setText(buku.getAuthor());
        penerbitTextView.setText(buku.getPublisher());
        tahunTextView.setText(buku.getYear());

        ImageButton btnEdit = (ImageButton) convertView.findViewById(R.id.edit);
        ImageButton btnDelete = (ImageButton) convertView.findViewById(R.id.hapus);

        btnEdit.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Intent intent = new Intent(getContext(), EditBukuActivity.class);
                   intent.putExtra("id",buku.getId());
                   intent.putExtra("judul",buku.getTitle());
                   intent.putExtra("pengarang",buku.getAuthor());
                   intent.putExtra("penerbit",buku.getPublisher());
                   intent.putExtra("tahun",buku.getYear());
                   getContext().startActivity(intent);
               }
           }
        );
        btnDelete.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View view) {
                     LibraryCrud librarycrud = new LibraryCrud();
                     librarycrud.deleteDataBuku(buku.getId());
                     notifyDataSetChanged();
                 }
             }
        );
        return convertView;
    }
}
