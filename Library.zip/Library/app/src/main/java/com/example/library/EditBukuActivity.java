package com.example.library;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.library.Crud.LibraryCrud;


public class EditBukuActivity extends AppCompatActivity {
    EditText  edtJudul , edtPengarang , edtPenerbit, edtTahun;
    TextView  txvId;
    Button btnsimpan;
    String id,judul,pengarang,penerbit,tahun;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_buku);

        txvId = (TextView) findViewById(R.id.txvide);
        edtJudul = (EditText) findViewById(R.id.edtJudul);
        edtPengarang = (EditText) findViewById(R.id.edtPengarang);
        edtPenerbit = (EditText) findViewById(R.id.edtPenerbit);
        edtTahun= (EditText) findViewById(R.id.edtTahun);

        txvId.setText(getIntent().getStringExtra("id"));
        edtJudul.setText(getIntent().getStringExtra("judul"));
        edtPengarang.setText(getIntent().getStringExtra("pengarang"));
        edtPenerbit.setText(getIntent().getStringExtra("penerbit"));
        edtTahun.setText(getIntent().getStringExtra("tahun"));


        btnsimpan = findViewById(R.id.updt);

        btnsimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                id = txvId.getText().toString();
                judul = edtJudul.getText().toString();
                pengarang = edtPengarang.getText().toString();
                penerbit = edtPenerbit.getText().toString();
                tahun = edtTahun.getText().toString();
                Log.d("TAG","id"+id+"buku"+judul+"pengarang"+pengarang+"penerbit"+pengarang+"tahun"+tahun);
                LibraryCrud librarycrud = new LibraryCrud();
                librarycrud.updateDataBuku(id,judul,pengarang,penerbit,tahun);
                finish();
            }
        });
    }
}