package com.example.library.Model;

import io.realm.RealmConfiguration;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.Required;

public class Buku  extends RealmObject {

    @PrimaryKey
    private String id;

    @Required
    private String title;
    private String author;
    private String publisher;
    private String year;


    public Buku(String id, String judul, String pengarang, String penerbit, String tahun) {
        this.id = id;
        this.title = judul;
        this.author = pengarang;
        this.publisher = penerbit;
        this.year = tahun;
    }

    public Buku() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}